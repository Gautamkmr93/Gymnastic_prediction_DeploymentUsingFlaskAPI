#importing required libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import time
import pickle

RawData=pd.read_csv('C:\\Users\\Gautam\\Desktop\\Api_Deploymnet_Gautam\\Gym_data.csv')
#RawData.describe()
RawData=RawData.drop('date',axis=1)
RawData=RawData.drop('is_start_of_semester',axis=1)
RawData=RawData.drop('is_during_semester',axis=1)
#RawData.head()
def time_to_seconds(time):
    return time.hour * 3600 + time.minute * 60 + time.second
noon = time_to_seconds(time(12, 0, 0))
RawData.timestamp = RawData.timestamp.apply(lambda t: abs(noon - t))
from sklearn.preprocessing import LabelEncoder
lb=LabelEncoder()
RawData['is_weekend']=lb.fit_transform(RawData['is_weekend'])
RawData['is_holiday']=lb.fit_transform(RawData['is_holiday'])
#RawData['is_start_of_semester']=lb.fit_transform(RawData['is_start_of_semester'])
#RawData['is_during_semester']=lb.fit_transform(RawData['is_during_semester'])
RawData['month']=lb.fit_transform(RawData['month'])
RawData['hour']=lb.fit_transform(RawData['hour'])
from sklearn.model_selection import train_test_split
x = RawData.iloc[:,1:].values
y = RawData.iloc[:, 0].values
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
#training/testing  the modeling
#print(X_test)
from sklearn.ensemble import RandomForestRegressor
create_model = RandomForestRegressor(n_estimators=10,random_state=0)
create_model.fit(x_train,y_train)
#y_pred=create_model.predict([[30674,4,68,7,20,1,0]])
#print(y_pred)
# Saving model to disk
pickle.dump(create_model, open('model.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))
#print(model.predict(x_test))

#print(y_pred)
#accuracy=model.score(x_test,y_test)
#print('accuracy :',accuracy * 100,'%')
#error=1-accuracy
#print('error:',error*100,'%')